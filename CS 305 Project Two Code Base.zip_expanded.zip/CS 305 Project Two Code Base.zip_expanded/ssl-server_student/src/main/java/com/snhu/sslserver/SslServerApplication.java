/*
 * Ben Verrill
 * CS-305
 * 10/1/21
 */

package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{  
	//Mapping that uses a GET request to display data at https://localhost:8443/hash
	@RequestMapping(value = "/hash", method = RequestMethod.GET)
	@ResponseBody
    public String myHash(){
    	String data = "Hello World, it's Ben Verrill!"; //Updated string value that includes my name
    	String  result;
    	MessageDigest digest;
		try {
			digest = java.security.MessageDigest.getInstance("SHA-256"); //MessageDigeeset object that uses SHA-256 algorithm cipher
	        digest.update(data.getBytes()); // Convert data string to bytes
	        byte[] messageDigest = digest.digest(); // Compute hash and store in byte array
	        result = String.format("Data: %s\nName of Cypher Algorithm: SHA-256\nChecksum Value: %s", data, bytesToHex(messageDigest)); // String to display on tomcat server that includes the original string and hash in hex format
	        System.out.println(result);
	        return result;
		} catch (NoSuchAlgorithmException e) {
			// Auto-generated catch block
			e.printStackTrace();
		}
    	
       
        return "<p>data:"+data;
    }

	// Method for converting bytes array to a hex string
	private String bytesToHex(byte[] messageDigest) {
		// Initialize StringBuffer object to store hex string
		StringBuffer hexString = new StringBuffer();
	    
		// Iterate through bytes array and convert to hex, then append result to hex string
	    for (int i = 0;i<messageDigest.length;i++) {
	       hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
	    }
	    
	    return hexString.toString();
	}
}
